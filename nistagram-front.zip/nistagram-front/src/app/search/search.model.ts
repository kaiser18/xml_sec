export class User{
    name: string;
    username: string;
    userProfilePic: string;
}