export class Comment {
    id: number;
    content: string;
    username: string;
    postId: number;
  }